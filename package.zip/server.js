'use strict';
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;
const rooms = new Map();
const MAX_PLAYERS = 8;
const WORLD = { width: 10000, height: 8000 };

app.use(express.static(__dirname));
app.get('/health', (_req, res) => res.json({ ok: true, rooms: rooms.size }));

function makeCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code;
  do {
    code = Array.from({length:5}, () => chars[Math.floor(Math.random()*chars.length)]).join('');
  } while (rooms.has(code));
  return code;
}
function cleanPlayer(p) {
  return {
    x: Math.max(0, Math.min(WORLD.width, Number(p.x) || 0)),
    y: Math.max(0, Math.min(WORLD.height, Number(p.y) || 0)),
    level: Math.max(1, Math.min(100, Math.floor(Number(p.level) || 1))),
    facing: Number(p.facing) < 0 ? -1 : 1,
    dead: !!p.dead,
    name: String(p.name || 'Игрок').slice(0, 18),
    form: String(p.form || 'Птица').slice(0, 20)
  };
}
function leaveRoom(socket) {
  const code = socket.data.roomCode;
  if (!code) return;
  const room = rooms.get(code);
  if (room) {
    room.delete(socket.id);
    socket.to(code).emit('player:left', { id: socket.id });
    if (room.size === 0) rooms.delete(code);
  }
  socket.leave(code);
  socket.data.roomCode = null;
}
io.on('connection', socket => {
  socket.data.roomCode = null;
  socket.on('room:create', payload => {
    leaveRoom(socket);
    const code = makeCode();
    const room = new Map();
    room.set(socket.id, cleanPlayer({ ...(payload||{}), x: 3750, y: 6000 }));
    rooms.set(code, room);
    socket.join(code);
    socket.data.roomCode = code;
    socket.emit('room:created', { code });
  });
  socket.on('room:join', payload => {
    const code = String(payload && payload.code || '').trim().toUpperCase();
    const room = rooms.get(code);
    if (!room) return socket.emit('room:error', { message: 'Комната не найдена. Проверь код.' });
    if (room.size >= MAX_PLAYERS) return socket.emit('room:error', { message: 'В комнате уже 8 игроков.' });
    leaveRoom(socket);
    const currentRoom = rooms.get(code);
    if (!currentRoom || currentRoom.size >= MAX_PLAYERS) return socket.emit('room:error', { message: 'Не удалось войти в комнату.' });
    currentRoom.set(socket.id, cleanPlayer({ ...(payload||{}), x: 3750, y: 6000 }));
    socket.join(code);
    socket.data.roomCode = code;
    const players = Object.fromEntries(currentRoom.entries());
    socket.emit('room:joined', { code, players });
    socket.to(code).emit('player:joined', { id: socket.id, player: currentRoom.get(socket.id) });
  });
  socket.on('player:update', payload => {
    const code = socket.data.roomCode;
    if (!code) return;
    const room = rooms.get(code);
    if (!room || !room.has(socket.id)) return;
    const player = cleanPlayer(payload || {});
    room.set(socket.id, player);
    socket.to(code).emit('player:moved', { id: socket.id, player });
  });
  socket.on('disconnect', () => leaveRoom(socket));
});
server.listen(PORT, '0.0.0.0', () => console.log(`Fly Game server listening on ${PORT}`));
