// FLY GAME 0.5 FIXED
// Исправлены кусты, текстуры еды и животных.
// Рисование объектов сделано Canvas-фигурами, а не зависит от emoji-шрифтов.

"use strict";

const canvas = document.getElementById("game");
if (!canvas) throw new Error('Нужен <canvas id="game"></canvas>');
const ctx = canvas.getContext("2d");
const WORLD = { width: 10000, height: 8000 };

const SETTINGS = {
    maxAnimals: 180, maxFood: 450, startAnimals: 150, startFood: 350,
    attackRange: 95, attackCooldown: 0.45, decorations: 1100
};

const BIOMES = [
    {id:"forest",name:"Лес",emoji:"🌳",color:"#4d8546",x:0,y:0,w:3333,h:4000,
     plants:["tree","pine","bush","mushroom","flower"],foods:["apple","berry","mushroom","pear"],
     animals:["mouse","rabbit","fox","owl","deer","wolf","hedgehog","bear","squirrel","boar"]},
    {id:"desert",name:"Пустыня",emoji:"🏜️",color:"#c6a45e",x:3333,y:0,w:3333,h:4000,
     plants:["cactus","cactus","rock","drygrass"],foods:["orange","carrot","corn"],
     animals:["snake","scorpion","camel","desertFox","lizard","eagle"]},
    {id:"snow",name:"Снежные земли",emoji:"❄️",color:"#b9d5df",x:6666,y:0,w:3334,h:4000,
     plants:["pine","pine","snowbush","rock"],foods:["grape","apple","mushroom"],
     animals:["penguin","polarBear","snowWolf","arcticFox","snowOwl","seal"]},
    {id:"swamp",name:"Болото",emoji:"🐸",color:"#547b50",x:0,y:4000,w:2500,h:4000,
     plants:["bush","mushroom","reed","tree"],foods:["mushroom","grape","cherry"],
     animals:["frog","crocodile","snake","turtle","mosquito","heron"]},
    {id:"meadow",name:"Цветочные луга",emoji:"🌻",color:"#79ae58",x:2500,y:4000,w:2500,h:4000,
     plants:["flower","flower2","sunflower","bush","tree"],foods:["apple","berry","cherry","pear","melon"],
     animals:["butterfly","bee","rabbit","duck","mouse","parrot","deer","squirrel"]},
    {id:"savanna",name:"Саванна",emoji:"🦁",color:"#b6a052",x:5000,y:4000,w:2500,h:4000,
     plants:["drygrass","palm","tree","rock"],foods:["melon","orange","carrot","corn"],
     animals:["lion","zebra","elephant","cheetah","hyena","ostrich"]},
    {id:"volcano",name:"Вулкан",emoji:"🌋",color:"#66504a",x:7500,y:4000,w:2500,h:4000,
     plants:["volcanoRock","rock","cactus","flame"],foods:["apple","mushroom","corn"],
     animals:["fireWolf","lavaBeetle","dragon","fireSnake","magmaGolem"]}
];

function getBiome(x,y) {
    return BIOMES.find(b=>x>=b.x&&x<b.x+b.w&&y>=b.y&&y<b.y+b.h)||BIOMES[4];
}

const SPECIES = {
 mouse:{name:"Мышь",emoji:"🐭",kind:"mouse",hp:35,speed:85,damage:0,xp:15,behavior:"flee",color:"#aaa"},
 rabbit:{name:"Кролик",emoji:"🐰",kind:"rabbit",hp:55,speed:110,damage:0,xp:30,behavior:"flee",color:"#ddd"},
 fox:{name:"Лиса",emoji:"🦊",kind:"fox",hp:100,speed:90,damage:12,xp:55,behavior:"hostile",color:"#df853c"},
 owl:{name:"Сова",emoji:"🦉",kind:"owl",hp:160,speed:95,damage:17,xp:100,behavior:"hostile",color:"#98704c"},
 deer:{name:"Олень",emoji:"🦌",kind:"deer",hp:130,speed:100,damage:0,xp:85,behavior:"flee",color:"#b17b4d"},
 wolf:{name:"Волк",emoji:"🐺",kind:"wolf",hp:180,speed:115,damage:20,xp:120,behavior:"hostile",color:"#929292"},
 hedgehog:{name:"Ёж",emoji:"🦔",kind:"hedgehog",hp:85,speed:45,damage:8,xp:35,behavior:"defend",color:"#947451"},
 bear:{name:"Медведь",emoji:"🐻",kind:"bear",hp:350,speed:70,damage:35,xp:250,behavior:"hostile",color:"#79543d"},
 squirrel:{name:"Белка",emoji:"🐿️",kind:"squirrel",hp:45,speed:125,damage:0,xp:25,behavior:"flee",color:"#bb743a"},
 boar:{name:"Кабан",emoji:"🐗",kind:"boar",hp:200,speed:85,damage:22,xp:140,behavior:"hostile",color:"#8b5d49"},
 snake:{name:"Змея",emoji:"🐍",kind:"snake",hp:90,speed:100,damage:15,xp:65,behavior:"hostile",color:"#7d9c40"},
 scorpion:{name:"Скорпион",emoji:"🦂",kind:"scorpion",hp:120,speed:65,damage:22,xp:100,behavior:"hostile",color:"#bd7137"},
 camel:{name:"Верблюд",emoji:"🐪",kind:"camel",hp:260,speed:55,damage:12,xp:180,behavior:"wander",color:"#c49a60"},
 desertFox:{name:"Пустынная лиса",emoji:"🦊",kind:"fox",hp:85,speed:135,damage:10,xp:75,behavior:"flee",color:"#d8b078"},
 lizard:{name:"Ящерица",emoji:"🦎",kind:"lizard",hp:45,speed:95,damage:5,xp:30,behavior:"flee",color:"#70a44d"},
 eagle:{name:"Орёл",emoji:"🦅",kind:"bird",hp:230,speed:125,damage:23,xp:160,behavior:"hostile",color:"#8b6546"},
 penguin:{name:"Пингвин",emoji:"🐧",kind:"penguin",hp:100,speed:65,damage:5,xp:60,behavior:"wander",color:"#444"},
 polarBear:{name:"Белый медведь",emoji:"🐻‍❄️",kind:"bear",hp:420,speed:75,damage:40,xp:300,behavior:"hostile",color:"#eee"},
 snowWolf:{name:"Снежный волк",emoji:"🐺",kind:"wolf",hp:220,speed:125,damage:24,xp:160,behavior:"hostile",color:"#d9e4e8"},
 arcticFox:{name:"Песец",emoji:"🦊",kind:"fox",hp:90,speed:120,damage:5,xp:80,behavior:"flee",color:"#eee"},
 snowOwl:{name:"Полярная сова",emoji:"🦉",kind:"owl",hp:180,speed:105,damage:18,xp:130,behavior:"hostile",color:"#eee"},
 seal:{name:"Тюлень",emoji:"🦭",kind:"seal",hp:180,speed:45,damage:5,xp:100,behavior:"wander",color:"#aaa"},
 frog:{name:"Лягушка",emoji:"🐸",kind:"frog",hp:50,speed:60,damage:4,xp:20,behavior:"wander",color:"#69bd56"},
 crocodile:{name:"Крокодил",emoji:"🐊",kind:"crocodile",hp:300,speed:60,damage:30,xp:220,behavior:"hostile",color:"#4c8c50"},
 turtle:{name:"Черепаха",emoji:"🐢",kind:"turtle",hp:150,speed:30,damage:5,xp:70,behavior:"wander",color:"#4b9c55"},
 mosquito:{name:"Комар",emoji:"🦟",kind:"bug",hp:20,speed:150,damage:5,xp:12,behavior:"hostile",color:"#555"},
 heron:{name:"Цапля",emoji:"🪿",kind:"bird",hp:130,speed:85,damage:12,xp:90,behavior:"flee",color:"#aaa"},
 butterfly:{name:"Бабочка",emoji:"🦋",kind:"butterfly",hp:20,speed:100,damage:0,xp:8,behavior:"flee",color:"#e8a5ff"},
 bee:{name:"Пчела",emoji:"🐝",kind:"bee",hp:30,speed:120,damage:5,xp:12,behavior:"defend",color:"#e8c34c"},
 duck:{name:"Утка",emoji:"🦆",kind:"bird",hp:70,speed:75,damage:0,xp:40,behavior:"flee",color:"#d7b94e"},
 parrot:{name:"Попугай",emoji:"🦜",kind:"bird",hp:90,speed:140,damage:10,xp:75,behavior:"flee",color:"#55a94d"},
 lion:{name:"Лев",emoji:"🦁",kind:"lion",hp:380,speed:105,damage:38,xp:280,behavior:"hostile",color:"#c49a40"},
 zebra:{name:"Зебра",emoji:"🦓",kind:"zebra",hp:150,speed:115,damage:0,xp:100,behavior:"flee",color:"#ddd"},
 elephant:{name:"Слон",emoji:"🐘",kind:"elephant",hp:600,speed:45,damage:45,xp:450,behavior:"hostile",color:"#888"},
 cheetah:{name:"Гепард",emoji:"🐆",kind:"fox",hp:220,speed:165,damage:28,xp:190,behavior:"hostile",color:"#c59b50"},
 hyena:{name:"Гиена",emoji:"🐕",kind:"wolf",hp:190,speed:105,damage:20,xp:145,behavior:"hostile",color:"#9d895e"},
 ostrich:{name:"Страус",emoji:"🦤",kind:"bird",hp:140,speed:145,damage:8,xp:95,behavior:"flee",color:"#555"},
 fireWolf:{name:"Огненный волк",emoji:"🐺",kind:"wolf",hp:330,speed:130,damage:35,xp:270,behavior:"hostile",color:"#e05b35"},
 lavaBeetle:{name:"Лавовый жук",emoji:"🪲",kind:"beetle",hp:170,speed:55,damage:18,xp:130,behavior:"hostile",color:"#e65c32"},
 dragon:{name:"Дракон",emoji:"🐉",kind:"dragon",hp:650,speed:110,damage:50,xp:500,behavior:"hostile",color:"#a84c42"},
 fireSnake:{name:"Огненная змея",emoji:"🐍",kind:"snake",hp:230,speed:125,damage:27,xp:190,behavior:"hostile",color:"#ed7435"},
 magmaGolem:{name:"Магмовый голем",emoji:"🗿",kind:"golem",hp:850,speed:35,damage:60,xp:650,behavior:"hostile",color:"#a54b38"}
};

const FORMS = [
 {level:1,name:"Птенец",emoji:"🐤",size:25,speed:210,damage:20},
 {level:3,name:"Быстрая птица",emoji:"🐦",size:29,speed:235,damage:30},
 {level:5,name:"Ястреб",emoji:"🦅",size:34,speed:255,damage:45},
 {level:8,name:"Могучий орёл",emoji:"🦅",size:42,speed:280,damage:65},
 {level:12,name:"Феникс",emoji:"🔥",size:47,speed:305,damage:85},
 {level:16,name:"Дракон",emoji:"🐉",size:54,speed:330,damage:110}
];

const player = {x:3750,y:6000,hp:100,maxHp:100,xp:0,level:1,size:25,speed:210,damage:20,
 attackTimer:0,damageTimer:0,facing:1,dead:false};
let currentForm=FORMS[0], animals=[], foods=[], particles=[], decorations=[];
const camera={x:0,y:0}, keys={}, mouse={x:0,y:0,down:false,rightDown:false};
let lastTime=0;

document.body.style.margin="0";
document.body.style.overflow="hidden";
document.body.style.background="#315c36";
canvas.style.display="block";
canvas.style.width="100vw";
canvas.style.height="100vh";
canvas.style.touchAction="none";

const hud=document.createElement("div");
hud.style.cssText="position:fixed;top:12px;left:12px;color:white;background:rgba(0,0,0,.72);padding:12px 16px;border-radius:12px;font:bold 14px Arial;line-height:1.65;pointer-events:none;z-index:10";
document.body.appendChild(hud);

const help=document.createElement("div");
help.style.cssText="position:fixed;bottom:10px;left:50%;transform:translateX(-50%);color:white;background:rgba(0,0,0,.6);padding:8px 14px;border-radius:10px;font:13px Arial;text-align:center;pointer-events:none;z-index:10";
help.textContent="WASD / стрелки — движение | ПРОБЕЛ или ЛКМ — атака | ПКМ — идти к курсору";
document.body.appendChild(help);

const deathScreen=document.createElement("div");
deathScreen.style.cssText="position:fixed;inset:0;display:none;align-items:center;justify-content:center;flex-direction:column;background:rgba(0,0,0,.85);color:white;font:bold 28px Arial;z-index:20";
deathScreen.innerHTML='<div>Ты проиграл!</div><div id="deathStats" style="font-size:18px;margin:15px"></div><button id="restartButton" style="padding:14px 28px;font-size:20px;border:0;border-radius:10px">Играть снова</button>';
document.body.appendChild(deathScreen);
document.getElementById("restartButton").onclick=restartGame;

function resizeCanvas(){
 const dpr=Math.min(window.devicePixelRatio||1,1.25);
 canvas.width=Math.floor(innerWidth*dpr);
 canvas.height=Math.floor(innerHeight*dpr);
 ctx.setTransform(dpr,0,0,dpr,0,0);
}
window.addEventListener("resize",resizeCanvas);
resizeCanvas();

window.addEventListener("keydown",e=>{
 keys[e.key.toLowerCase()]=true;
 if(e.code==="Space"){e.preventDefault();attack();}
});
window.addEventListener("keyup",e=>{keys[e.key.toLowerCase()]=false;});
canvas.addEventListener("mousemove",e=>{mouse.x=e.clientX;mouse.y=e.clientY;});
canvas.addEventListener("mousedown",e=>{
 if(e.button===0){mouse.down=true;attack();}
 if(e.button===2){mouse.rightDown=true;}
});
window.addEventListener("mouseup",e=>{
 if(e.button===0)mouse.down=false;
 if(e.button===2)mouse.rightDown=false;
});
canvas.addEventListener("contextmenu",e=>e.preventDefault());

function rand(min,max){return Math.random()*(max-min)+min;}
function pick(arr){return arr[Math.floor(Math.random()*arr.length)];}
function clamp(v,min,max){return Math.max(min,Math.min(max,v));}
function distance(a,b){return Math.hypot(a.x-b.x,a.y-b.y);}
function xpNeeded(){return 100+player.level*65;}
function createWorld(){
 animals=[];foods=[];particles=[];decorations=[];
 for(let i=0;i<SETTINGS.decorations;i++){
  const x=rand(40,WORLD.width-40),y=rand(40,WORLD.height-40),b=getBiome(x,y);
  decorations.push({x,y,type:pick(b.plants),scale:rand(.65,1.35),seed:rand(0,100)});
 }
 for(let i=0;i<SETTINGS.startAnimals;i++)spawnAnimal();
 for(let i=0;i<SETTINGS.startFood;i++)spawnFood();
}

function spawnAnimal(){
 if(animals.length>=SETTINGS.maxAnimals)return;
 const x=rand(30,WORLD.width-30),y=rand(30,WORLD.height-30);
 const b=getBiome(x,y),id=pick(b.animals),s=SPECIES[id];
 if(!s)return;
 animals.push({
  x,y,species:s,hp:s.hp,maxHp:s.hp,speed:s.speed,damage:s.damage,
  direction:rand(-1,1),vx:0,vy:0,think:rand(.2,2),
  hitFlash:0,attackTimer:0
 });
}

function spawnFood(){
 if(foods.length>=SETTINGS.maxFood)return;
 const x=rand(30,WORLD.width-30),y=rand(30,WORLD.height-30);
 const b=getBiome(x,y),type=pick(b.foods);
 foods.push({x,y,type,value:rand(12,30),scale:rand(.8,1.2),phase:rand(0,7)});
}

function addXP(amount){
 player.xp+=amount;
 while(player.xp>=xpNeeded()){
  player.xp-=xpNeeded();
  player.level++;
  player.maxHp+=15;
  player.hp=player.maxHp;
  player.damage+=5;
  player.speed+=5;
  const form=[...FORMS].reverse().find(f=>player.level>=f.level);
  if(form&&form.level>currentForm.level){
   currentForm=form;
   player.size=form.size;
   player.speed=form.speed;
   player.damage=form.damage;
  }
 }
}

function attack(){
 if(player.dead||player.attackTimer>0)return;
 player.attackTimer=SETTINGS.attackCooldown;
 let target=null,best=SETTINGS.attackRange;
 const aim={x:mouse.x+camera.x,y:mouse.y+camera.y};
 for(const a of animals){
  const d=Math.hypot(a.x-player.x,a.y-player.y);
  if(d<best){best=d;target=a;}
 }
 if(target){
  target.hp-=player.damage;
  target.hitFlash=.15;
  const dx=target.x-player.x,dy=target.y-player.y;
  const len=Math.hypot(dx,dy)||1;
  target.x+=dx/len*18;
  target.y+=dy/len*18;
  if(target.hp<=0){
   addXP(target.species.xp);
   for(let i=0;i<3;i++)particles.push({x:target.x,y:target.y,life:1,emoji:"✦"});
   animals.splice(animals.indexOf(target),1);
   for(let i=0;i<2;i++)spawnFood();
  }
 }else{
  const dx=aim.x-player.x;
  if(Math.abs(dx)>2)player.facing=Math.sign(dx);
 }
}

function updatePlayer(dt){
 const oldHp=player.hp;
 player.attackTimer=Math.max(0,player.attackTimer-dt);
 player.damageTimer=Math.max(0,player.damageTimer-dt);
 let dx=0,dy=0;
 if(keys["w"]||keys["arrowup"])dy--;
 if(keys["s"]||keys["arrowdown"])dy++;
 if(keys["a"]||keys["arrowleft"])dx--;
 if(keys["d"]||keys["arrowright"])dx++;
 if(mouse.rightDown){
  const tx=mouse.x+camera.x-player.x,ty=mouse.y+camera.y-player.y;
  const len=Math.hypot(tx,ty);
  if(len>15){dx=tx/len;dy=ty/len;}
 }
 const len=Math.hypot(dx,dy);
 if(len>0){
  dx/=len;dy/=len;
  player.x+=dx*player.speed*dt;
  player.y+=dy*player.speed*dt;
  if(dx!==0)player.facing=Math.sign(dx);
 }
 player.x=clamp(player.x,player.size,WORLD.width-player.size);
 player.y=clamp(player.y,player.size,WORLD.height-player.size);
 if(player.hp<player.maxHp&&player.damageTimer<=0){
  player.hp=Math.min(player.maxHp,player.hp+8*dt);
 }
 if(player.hp<=0)endGame();
}

function updateAnimals(dt){
 for(let i=animals.length-1;i>=0;i--){
  const a=animals[i],s=a.species;
  a.think-=dt;
  a.hitFlash=Math.max(0,a.hitFlash-dt);
  a.attackTimer=Math.max(0,a.attackTimer-dt);
  const dx=player.x-a.x,dy=player.y-a.y,d=Math.hypot(dx,dy)||1;
  let mx=0,my=0;
  if(s.behavior==="hostile"&&d<300){
   mx=dx/d;my=dy/d;
   if(d<player.size+18&&a.attackTimer<=0){
    player.hp-=s.damage;
    player.damageTimer=5;
    a.attackTimer=1;
    if(player.hp<=0)endGame();
   }
  }else if(s.behavior==="flee"&&d<150){
   mx=-dx/d;my=-dy/d;
  }else if(s.behavior==="defend"&&d<100){
   mx=dx/d;my=dy/d;
  }else if(a.think<=0){
   a.think=rand(.6,2.5);
   const angle=rand(0,Math.PI*2);
   a.vx=Math.cos(angle);a.vy=Math.sin(angle);
  }
  if(mx===0&&my===0){mx=a.vx;my=a.vy;}
  const ml=Math.hypot(mx,my)||1;
  a.x+=mx/ml*a.speed*dt;
  a.y+=my/ml*a.speed*dt;
  a.x=clamp(a.x,10,WORLD.width-10);
  a.y=clamp(a.y,10,WORLD.height-10);
  if(mx!==0)a.direction=Math.sign(mx);
 }
 while(animals.length<SETTINGS.maxAnimals&&Math.random()<dt*.8)spawnAnimal();
}

function updateFood(){
 for(let i=foods.length-1;i>=0;i--){
  const f=foods[i];
  if(Math.hypot(f.x-player.x,f.y-player.y)<player.size+18){
   addXP(f.value);
   particles.push({x:f.x,y:f.y,life:1,emoji:"+"+Math.round(f.value)});
   foods.splice(i,1);
  }
 }
 while(foods.length<SETTINGS.maxFood&&Math.random()<.8)spawnFood();
}

function updateParticles(dt){
 for(let i=particles.length-1;i>=0;i--){
  particles[i].life-=dt;
  particles[i].y-=25*dt;
  if(particles[i].life<=0)particles.splice(i,1);
 }
}

function updateCamera(){
 const w=innerWidth,h=innerHeight;
 camera.x=clamp(player.x-w/2,0,WORLD.width-w);
 camera.y=clamp(player.y-h/2,0,WORLD.height-h);
}

function visible(x,y,pad=30){
 return x>camera.x-pad&&x<camera.x+innerWidth+pad&&
        y>camera.y-pad&&y<camera.y+innerHeight+pad;
}

function drawBackground(){
 const w=innerWidth,h=innerHeight;
 ctx.fillStyle="#4f9147";
 ctx.fillRect(0,0,w,h);
 const startX=Math.floor(camera.x/200)*200;
 const startY=Math.floor(camera.y/200)*200;
 for(let x=startX;x<camera.x+w+200;x+=200){
  for(let y=startY;y<camera.y+h+200;y+=200){
   const b=getBiome(x,y);
   ctx.fillStyle=b.color;
   ctx.globalAlpha=.2;
   ctx.fillRect(x-camera.x,y-camera.y,200,200);
   ctx.globalAlpha=1;
  }
 }
 // Границы мира
 ctx.strokeStyle="#263d27";
 ctx.lineWidth=8;
 ctx.strokeRect(-camera.x,-camera.y,WORLD.width,WORLD.height);
}

function ellipse(x,y,rx,ry,color,stroke="rgba(0,0,0,.22)"){
 ctx.fillStyle=color;
 ctx.beginPath();
 ctx.ellipse(x,y,rx,ry,0,0,Math.PI*2);
 ctx.fill();
 if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1.5;ctx.stroke();}
}

function drawPlant(d){
 const x=d.x-camera.x,y=d.y-camera.y,s=d.scale;
 ctx.save();
 ctx.translate(x,y);
 ctx.scale(s,s);
 switch(d.type){
  case "bush":
   ellipse(-9,2,12,10,"#286b32");
   ellipse(3,-5,14,13,"#398b3e");
   ellipse(13,3,11,9,"#2d7837");
   for(let i=0;i<5;i++){
    ctx.fillStyle="#70ad50";
    ctx.beginPath();ctx.arc(-9+i*6,-7+(i%2)*5,2,0,7);ctx.fill();
   }
   break;
  case "tree":
   ctx.fillStyle="#74502f";ctx.fillRect(-4,0,8,24);
   ellipse(0,-7,19,18,"#246b32");
   ellipse(-10,-3,11,12,"#347d39");
   ellipse(9,-13,12,13,"#3d8b42");
   break;
  case "pine":
   ctx.fillStyle="#74502f";ctx.fillRect(-3,4,6,18);
   ctx.fillStyle="#245b39";
   for(let i=0;i<3;i++){
    ctx.beginPath();ctx.moveTo(0,-25+i*12);ctx.lineTo(-15,4+i*9);ctx.lineTo(15,4+i*9);ctx.closePath();ctx.fill();
   }
   break;
  case "flower":
  case "flower2":
  case "sunflower":
   ctx.strokeStyle="#397b31";ctx.lineWidth=3;
   ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(0,-17);ctx.stroke();
   const petal=d.type==="sunflower"?"#f3c73e":(d.seed%2?"#e68acb":"#f4e7ec");
   for(let i=0;i<6;i++){
    const a=i*Math.PI/3;
    ellipse(Math.cos(a)*6,-17+Math.sin(a)*6,4,4,petal,"none");
   }
   ellipse(0,-17,3,3,"#9b6530","none");
   break;
  case "mushroom":
   ctx.fillStyle="#eee2c7";ctx.fillRect(-3,-4,6,12);
   ellipse(0,-7,10,6,"#c94b3b");
   break;
  case "cactus":
   ctx.fillStyle="#38894a";
   ctx.fillRect(-5,-18,10,27);
   ctx.fillRect(-13,-10,8,5);ctx.fillRect(-13,-15,5,10);
   ctx.fillRect(5,-5,8,5);ctx.fillRect(8,-12,5,12);
   break;
  case "rock":
  case "volcanoRock":
   ctx.fillStyle=d.type==="rock"?"#858b83":"#5b3930";
   ctx.beginPath();ctx.moveTo(-15,8);ctx.lineTo(-11,-5);ctx.lineTo(-2,-13);
   ctx.lineTo(12,-7);ctx.lineTo(16,8);ctx.closePath();ctx.fill();
   break;
  case "snowbush":
   ellipse(0,0,15,10,"#dcecf0");
   ellipse(-7,-5,8,7,"#f7ffff");
   break;
  case "drygrass":
   ctx.strokeStyle="#c5a04e";ctx.lineWidth=3;
   for(let i=-2;i<=2;i++){
    ctx.beginPath();ctx.moveTo(0,8);ctx.lineTo(i*5,-rand(8,17));ctx.stroke();
   }
   break;
  case "reed":
   ctx.strokeStyle="#56834b";ctx.lineWidth=3;
   for(let i=-2;i<=2;i++){
    ctx.beginPath();ctx.moveTo(i*4,8);ctx.lineTo(i*4-2,-20);ctx.stroke();
   }
   break;
  case "palm":
   ctx.fillStyle="#8c633b";ctx.fillRect(-3,-3,6,22);
   ctx.strokeStyle="#34773b";ctx.lineWidth=5;
   for(let i=0;i<6;i++){
    const a=i*Math.PI/3;
    ctx.beginPath();ctx.moveTo(0,-4);ctx.quadraticCurveTo(Math.cos(a)*10,-20,Math.cos(a)*22,-10+Math.sin(a)*12);ctx.stroke();
   }
   break;
  case "flame":
   ctx.fillStyle="#e65a2c";ctx.beginPath();ctx.moveTo(0,10);ctx.quadraticCurveTo(-15,-4,0,-22);ctx.quadraticCurveTo(15,-4,0,10);ctx.fill();
   ctx.fillStyle="#ffc34b";ctx.beginPath();ctx.moveTo(0,6);ctx.quadraticCurveTo(-7,-3,0,-13);ctx.quadraticCurveTo(8,-3,0,6);ctx.fill();
   break;
 }
 ctx.restore();
}
function drawFoodItem(f){
 const x=f.x-camera.x,y=f.y-camera.y,s=f.scale;
 ctx.save();ctx.translate(x,y);ctx.scale(s,s);
 switch(f.type){
  case "apple":
   ellipse(0,0,9,10,"#d94335");
   ctx.strokeStyle="#68462b";ctx.lineWidth=2;
   ctx.beginPath();ctx.moveTo(0,-8);ctx.lineTo(2,-14);ctx.stroke();
   ellipse(5,-10,5,3,"#4c9a43","none");
   break;
  case "berry":
   for(let i=0;i<5;i++)ellipse(Math.cos(i*1.25)*6,Math.sin(i*1.25)*5,4,4,"#543caa");
   break;
  case "mushroom":
   ctx.fillStyle="#eee1c6";ctx.fillRect(-3,-1,6,10);
   ellipse(0,-3,9,6,"#d34d43");
   break;
  case "pear":
   ellipse(0,2,8,10,"#9acb45");
   ellipse(0,-5,5,6,"#9acb45");
   break;
  case "orange":
   ellipse(0,0,9,9,"#f49a32");
   ellipse(3,-9,4,2,"#478d3c");
   break;
  case "carrot":
   ctx.fillStyle="#ed8732";ctx.beginPath();
   ctx.moveTo(-6,-7);ctx.lineTo(7,-7);ctx.lineTo(0,12);ctx.closePath();ctx.fill();
   ctx.strokeStyle="#4d9b42";ctx.lineWidth=3;
   ctx.beginPath();ctx.moveTo(0,-7);ctx.lineTo(-3,-13);ctx.moveTo(0,-7);ctx.lineTo(4,-13);ctx.stroke();
   break;
  case "corn":
   ellipse(0,0,7,12,"#f2d34c");
   ctx.strokeStyle="#75a748";ctx.lineWidth=3;
   ctx.beginPath();ctx.moveTo(-5,8);ctx.lineTo(-10,13);ctx.moveTo(5,8);ctx.lineTo(10,13);ctx.stroke();
   break;
  case "grape":
   for(let i=0;i<7;i++)ellipse((i%3-1)*6,Math.floor(i/3)*6-3,4,4,"#7952a8");
   break;
  case "cherry":
   ctx.strokeStyle="#47843a";ctx.lineWidth=2;
   ctx.beginPath();ctx.moveTo(-3,-2);ctx.lineTo(0,-11);ctx.lineTo(6,-8);ctx.stroke();
   ellipse(-4,2,5,5,"#c8323a");ellipse(7,2,5,5,"#c8323a");
   break;
  case "melon":
   ellipse(0,0,12,8,"#4f9c4a");
   ctx.strokeStyle="#a5c96c";ctx.lineWidth=2;
   ctx.beginPath();ctx.moveTo(-8,-4);ctx.lineTo(8,4);ctx.moveTo(-8,4);ctx.lineTo(8,-4);ctx.stroke();
   break;
 }
 ctx.restore();
}

function drawAnimalShape(a){
 const x=a.x-camera.x,y=a.y-camera.y,s=a.species,kind=s.kind||"animal";
 ctx.save();ctx.translate(x,y);ctx.rotate(a.direction*.08);
 const c=s.color;
 if(kind==="snake"){
  ctx.strokeStyle=c;ctx.lineWidth=9;ctx.lineCap="round";
  ctx.beginPath();ctx.moveTo(-18,4);ctx.quadraticCurveTo(-8,-12,2,3);
  ctx.quadraticCurveTo(12,16,20,-2);ctx.stroke();
  ctx.fillStyle=c;ctx.beginPath();ctx.arc(20,-2,6,0,7);ctx.fill();
 }
 else if(kind==="butterfly"){
  ctx.fillStyle=c;ctx.beginPath();
  ctx.ellipse(-9,-7,10,13,-.5,0,7);ctx.ellipse(9,-7,10,13,.5,0,7);
  ctx.ellipse(-8,8,8,10,.5,0,7);ctx.ellipse(8,8,8,10,-.5,0,7);
  ctx.fill();ctx.strokeStyle="#493b27";ctx.lineWidth=2;
  ctx.beginPath();ctx.moveTo(0,-5);ctx.lineTo(0,12);ctx.stroke();
 }
 else if(kind==="bird"||kind==="owl"||kind==="penguin"){
  ellipse(0,2,13,17,c);
  ellipse(0,7,8,10,kind==="penguin"?"#f4f2e9":"#e9dfc7","none");
  ctx.fillStyle="#e69a35";ctx.beginPath();
  ctx.moveTo(10,-3);ctx.lineTo(22,1);ctx.lineTo(10,5);ctx.fill();
  ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(5,-6,3.5,0,7);ctx.fill();
  ctx.fillStyle="#171717";ctx.beginPath();ctx.arc(6,-6,1.7,0,7);ctx.fill();
 }
 else if(kind==="elephant"){
  ellipse(-2,0,18,13,c);ellipse(13,-5,10,10,c);
  ctx.strokeStyle=c;ctx.lineWidth=6;ctx.beginPath();
  ctx.moveTo(19,-1);ctx.quadraticCurveTo(30,8,22,17);ctx.stroke();
  ctx.fillStyle="#eee";ctx.beginPath();ctx.moveTo(10,3);
  ctx.lineTo(18,13);ctx.lineTo(14,4);ctx.fill();
 }
 else if(kind==="lion"){
  ellipse(0,0,19,19,"#a96527");ellipse(2,0,13,13,c);
  ctx.fillStyle="#f4d18a";ctx.beginPath();
  ctx.arc(9,-5,3,0,7);ctx.arc(9,5,3,0,7);ctx.fill();
 }
 else if(kind==="crocodile"){
  ellipse(0,0,19,10,c);
  ctx.fillStyle=c;ctx.beginPath();ctx.ellipse(15,-2,13,6,0,0,7);ctx.fill();
  ctx.fillStyle="#f5e7b0";
  for(let i=0;i<5;i++){
   ctx.beginPath();ctx.moveTo(8+i*4,2);
   ctx.lineTo(10+i*4,7);ctx.lineTo(12+i*4,2);ctx.fill();
  }
 }
 else if(kind==="turtle"){
  ellipse(0,0,17,13,"#397747");ellipse(0,-1,12,10,"#a4773c");
  ctx.strokeStyle="#e0bd72";ctx.lineWidth=1;ctx.beginPath();
  ctx.moveTo(-10,-1);ctx.lineTo(10,-1);
  ctx.moveTo(0,-10);ctx.lineTo(0,9);ctx.stroke();
 }
 else if(kind==="bee"||kind==="bug"){
  ellipse(0,0,12,8,c);
  ctx.strokeStyle="#332b20";ctx.lineWidth=3;ctx.beginPath();
  ctx.moveTo(-4,-7);ctx.lineTo(-4,7);ctx.moveTo(4,-7);ctx.lineTo(4,7);ctx.stroke();
  ctx.fillStyle="rgba(235,250,255,.8)";
  ellipse(-5,-10,5,3,"rgba(235,250,255,.8)","none");
  ellipse(5,-10,5,3,"rgba(235,250,255,.8)","none");
 }
 else if(kind==="dragon"){
  ellipse(-2,2,16,11,c);
  ctx.fillStyle=c;ctx.beginPath();
  ctx.moveTo(-5,-5);ctx.lineTo(-20,-19);ctx.lineTo(-14,1);
  ctx.moveTo(5,-5);ctx.lineTo(20,-19);ctx.lineTo(14,1);ctx.fill();
  ctx.beginPath();ctx.moveTo(13,0);ctx.lineTo(25,-5);
  ctx.lineTo(19,8);ctx.fill();
  ctx.fillStyle="#f4a23c";ctx.beginPath();
  ctx.moveTo(18,3);ctx.lineTo(29,7);ctx.lineTo(18,9);ctx.fill();
 }
 else if(kind==="golem"){
  ellipse(0,0,16,17,c);
  ctx.fillStyle="#ff8b32";ctx.fillRect(-8,-5,5,4);ctx.fillRect(4,-5,5,4);
  ctx.strokeStyle="#ff6a2a";ctx.lineWidth=3;
  ctx.beginPath();ctx.moveTo(-8,9);ctx.lineTo(8,9);ctx.stroke();
 }
 else if(kind==="camel"){
  ellipse(0,3,19,10,c);ellipse(-7,-7,6,8,c);ellipse(8,-7,6,8,c);
  ctx.strokeStyle=c;ctx.lineWidth=4;
  for(let xx of [-10,9]){
   ctx.beginPath();ctx.moveTo(xx,8);ctx.lineTo(xx+2,20);ctx.stroke();
  }
 }
 else if(kind==="deer"){
  ellipse(0,3,15,10,c);ellipse(12,-5,7,8,c);
  ctx.strokeStyle="#8c6038";ctx.lineWidth=2;ctx.beginPath();
  ctx.moveTo(12,-12);ctx.lineTo(8,-22);ctx.lineTo(3,-25);
  ctx.moveTo(12,-12);ctx.lineTo(17,-22);ctx.lineTo(22,-25);ctx.stroke();
 }
 else if(kind==="hedgehog"){
  ellipse(0,4,15,11,"#9c7950");
  ctx.strokeStyle="#55432f";ctx.lineWidth=2;
  for(let i=-2;i<=2;i++){
   ctx.beginPath();ctx.moveTo(i*5,-3);ctx.lineTo(i*6-3,-17);ctx.stroke();
  }
  ellipse(12,3,6,5,"#d3b28b");
 }
 else if(kind==="squirrel"){
  ellipse(0,4,10,12,c);
  ctx.strokeStyle=c;ctx.lineWidth=6;ctx.beginPath();
  ctx.arc(-7,-8,10,0,Math.PI*1.7);ctx.stroke();
  ellipse(8,-5,6,7,c);
 }
 else if(kind==="scorpion"){
  ellipse(0,5,12,7,c);ctx.strokeStyle=c;ctx.lineWidth=4;
  ctx.beginPath();ctx.moveTo(8,1);ctx.quadraticCurveTo(20,-12,14,-20);ctx.stroke();
  ctx.fillStyle=c;ctx.beginPath();ctx.arc(14,-20,4,0,7);ctx.fill();
  ctx.strokeStyle=c;ctx.lineWidth=3;ctx.beginPath();
  ctx.moveTo(-7,4);ctx.lineTo(-16,12);
  ctx.moveTo(7,4);ctx.lineTo(16,12);ctx.stroke();
 }
 else if(kind==="frog"){
  ellipse(0,3,14,11,c);ellipse(-7,-7,5,6,c);ellipse(7,-7,5,6,c);
  ctx.fillStyle="#fff";ctx.beginPath();
  ctx.arc(-7,-8,2,0,7);ctx.arc(7,-8,2,0,7);ctx.fill();
 }
 else if(kind==="seal"){
  ellipse(0,4,19,10,c);ellipse(13,-2,8,8,c);
  ctx.fillStyle="#222";ctx.beginPath();ctx.arc(16,-4,1.5,0,7);ctx.fill();
 }
 else if(kind==="lizard"){
  ellipse(0,0,13,7,c);ctx.strokeStyle=c;ctx.lineWidth=3;
  ctx.beginPath();ctx.moveTo(-10,0);ctx.lineTo(-23,-8);
  ctx.moveTo(-5,4);ctx.lineTo(-12,12);
  ctx.moveTo(7,4);ctx.lineTo(14,12);ctx.stroke();
 }
 else if(kind==="zebra"){
  ellipse(0,2,17,11,"#eee");ctx.strokeStyle="#242424";ctx.lineWidth=2;
  for(let i=-2;i<=2;i++){
   ctx.beginPath();ctx.moveTo(i*6,-7);ctx.lineTo(i*6-4,10);ctx.stroke();
  }
  ellipse(13,-5,7,7,"#eee");
 }
 else if(kind==="beetle"){
  ellipse(0,2,15,12,c);ctx.strokeStyle="#4b2920";ctx.lineWidth=2;
  ctx.beginPath();ctx.moveTo(0,-9);ctx.lineTo(0,13);ctx.stroke();
 }
 else {
  ellipse(-1,2,15,10,c);
  ellipse(12,-5,8,8,c);
  ctx.strokeStyle=c;ctx.lineWidth=4;ctx.beginPath();
  ctx.moveTo(-9,8);ctx.lineTo(-11,17);
  ctx.moveTo(4,8);ctx.lineTo(5,17);ctx.stroke();
  if(kind==="rabbit"||kind==="mouse"||kind==="fox"||kind==="wolf"){
   ellipse(8,-14,3,7,c);ellipse(16,-13,3,7,c);
  }
  if(kind==="fox"||kind==="wolf"||kind==="bear"){
   ctx.strokeStyle=c;ctx.lineWidth=5;ctx.beginPath();
   ctx.moveTo(-14,0);ctx.quadraticCurveTo(-25,-8,-22,-15);ctx.stroke();
  }
  ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(15,-7,2.5,0,7);ctx.fill();
  ctx.fillStyle="#171717";ctx.beginPath();ctx.arc(16,-7,1.2,0,7);ctx.fill();
  if(kind==="boar"){
   ctx.fillStyle="#eee";ctx.beginPath();ctx.moveTo(17,-1);
   ctx.lineTo(24,2);ctx.lineTo(17,4);ctx.fill();
  }
 }
 if(a.hitFlash>0){
  ctx.fillStyle="rgba(255,255,255,.4)";
  ctx.beginPath();ctx.arc(0,0,24,0,7);ctx.fill();
 }
 ctx.restore();

 const bx=x-19,by=y-29;
 ctx.fillStyle="#222";ctx.fillRect(bx,by,38,5);
 ctx.fillStyle="#e64c4c";
 ctx.fillRect(bx,by,38*Math.max(0,a.hp/a.maxHp),5);
}

function drawDecorations(){
 for(const d of decorations)if(visible(d.x,d.y,50))drawPlant(d);
}
function drawFood(){
 for(const f of foods)if(visible(f.x,f.y,40))drawFoodItem(f);
}
function drawAnimals(){
 for(const a of animals)if(visible(a.x,a.y,70))drawAnimalShape(a);
}

function drawPlayer(){
 const x=player.x-camera.x,y=player.y-camera.y,s=player.size;
 const colors=["#e8d85b","#65c7e8","#a5a5b8","#e4a63d","#f07832","#bd493b"];
 let color=colors[0];
 if(player.level>=3)color=colors[1];
 if(player.level>=5)color=colors[2];
 if(player.level>=8)color=colors[3];
 if(player.level>=12)color=colors[4];
 if(player.level>=16)color=colors[5];

 ctx.save();ctx.translate(x,y);ctx.scale(player.facing,1);
 ctx.fillStyle="rgba(0,0,0,.22)";
 ctx.beginPath();ctx.ellipse(0,s*.65,s*.9,s*.3,0,0,7);ctx.fill();
 ctx.fillStyle="#bd8c43";ctx.beginPath();
 ctx.moveTo(-s*.5,0);ctx.lineTo(-s*1.25,-s*.35);
 ctx.lineTo(-s*1.1,s*.45);ctx.closePath();ctx.fill();
 ctx.fillStyle=color;ctx.strokeStyle="#493b27";ctx.lineWidth=2.5;
 ctx.beginPath();ctx.ellipse(0,0,s*.9,s*.65,0,0,7);ctx.fill();ctx.stroke();
 ctx.fillStyle="#f5e6b8";ctx.beginPath();
 ctx.ellipse(-s*.1,s*.05,s*.48,s*.3,-.4,0,7);ctx.fill();ctx.stroke();
 ctx.fillStyle=color;ctx.beginPath();ctx.arc(s*.55,-s*.35,s*.4,0,7);ctx.fill();ctx.stroke();
 ctx.fillStyle="#f49b32";ctx.beginPath();
 ctx.moveTo(s*.83,-s*.35);ctx.lineTo(s*1.35,-s*.2);
 ctx.lineTo(s*.83,-s*.05);ctx.closePath();ctx.fill();
 ctx.fillStyle="white";ctx.beginPath();ctx.arc(s*.65,-s*.43,s*.12,0,7);ctx.fill();
 ctx.fillStyle="#171717";ctx.beginPath();ctx.arc(s*.69,-s*.43,s*.055,0,7);ctx.fill();
 ctx.restore();

 ctx.strokeStyle="rgba(255,255,255,.85)";ctx.lineWidth=2;
 ctx.beginPath();ctx.arc(x,y,s+5,0,7);ctx.stroke();
}

function drawParticles(){
 for(const p of particles){
  if(!visible(p.x,p.y))continue;
  ctx.globalAlpha=clamp(p.life,0,1);
  ctx.font="18px Arial";ctx.textAlign="center";ctx.textBaseline="middle";
  ctx.fillText(p.emoji,p.x-camera.x,p.y-camera.y);
 }
 ctx.globalAlpha=1;
}

function updateHUD(){
 const b=getBiome(player.x,player.y),percent=player.xp/xpNeeded()*100;
 hud.innerHTML=`${currentForm.emoji} ${currentForm.name} — уровень ${player.level}<br>
 ❤️ Здоровье: ${Math.ceil(player.hp)} / ${player.maxHp}
 <div style="width:190px;height:8px;background:#555;border-radius:5px;overflow:hidden">
 <div style="width:${player.hp/player.maxHp*100}%;height:100%;background:#e64b4b"></div></div>
 ⭐ Опыт: ${Math.floor(player.xp)} / ${xpNeeded()}
 <div style="width:190px;height:8px;background:#555;border-radius:5px;overflow:hidden">
 <div style="width:${percent}%;height:100%;background:#f4d34e"></div></div>
 ⚔️ Урон: ${player.damage}<br>${b.emoji} Биом: ${b.name}<br>
 🐾 Животных: ${animals.length}<br>🍎 Еды: ${foods.length}`;
}

function endGame(){
 if(player.dead)return;
 player.dead=true;
 document.getElementById("deathStats").textContent=
  `Уровень: ${player.level} | Опыт: ${Math.floor(player.xp)}`;
 deathScreen.style.display="flex";
}

function restartGame(){
 Object.assign(player,{
  x:3750,y:6000,hp:100,maxHp:100,xp:0,level:1,
  size:25,speed:210,damage:20,attackTimer:0,
  damageTimer:0,dead:false,facing:1
 });
 currentForm=FORMS[0];
 createWorld();updateCamera();updateHUD();
 deathScreen.style.display="none";
}

function update(dt){
 if(player.dead)return;
 updatePlayer(dt);
 updateAnimals(dt);
 updateFood();
 updateParticles(dt);
 updateCamera();
 updateHUD();
}

function render(){
 drawBackground();
 drawDecorations();
 drawFood();
 drawAnimals();
 drawParticles();
 drawPlayer();
 drawRemotePlayers();
}

function gameLoop(timestamp){
 const dt=Math.min((timestamp-lastTime)/1000||0,.04);
 lastTime=timestamp;
 update(dt);
 render();
 requestAnimationFrame(gameLoop);
}

createWorld();
updateCamera();
updateHUD();
requestAnimationFrame(gameLoop);

// =============================================
// FLY GAME MULTIPLAYER CLIENT (rooms + players)
// =============================================
(function setupFlyGameMultiplayer(){
 const mpPanel=document.createElement("div");
 mpPanel.id="multiplayerPanel";
 mpPanel.style.cssText="position:fixed;right:12px;top:12px;z-index:10000;width:230px;padding:12px;background:rgba(12,25,18,.88);color:#fff;border:1px solid rgba(255,255,255,.25);border-radius:12px;font:14px Arial,sans-serif;box-shadow:0 4px 18px #0006";
 mpPanel.innerHTML=`
  <div style="font-weight:bold;font-size:16px;margin-bottom:8px">🌐 Мультиплеер</div>
  <div id="mpStatus" style="font-size:12px;color:#ffd36b;margin-bottom:8px">Подключение к серверу...</div>
  <button id="mpCreate" style="width:100%;padding:8px;margin:3px 0;cursor:pointer">Создать комнату</button>
  <div style="display:flex;gap:5px;margin-top:5px">
   <input id="mpCode" maxlength="5" placeholder="Код комнаты" style="min-width:0;width:100%;padding:7px;text-transform:uppercase">
   <button id="mpJoin" style="padding:7px;cursor:pointer">Войти</button>
  </div>
  <div id="mpRoom" style="margin-top:8px;font-size:12px">Комната: нет</div>
  <div id="mpCount" style="font-size:12px">Игроков: 1</div>
 `;
 document.body.appendChild(mpPanel);
 const statusEl=mpPanel.querySelector("#mpStatus");
 const roomEl=mpPanel.querySelector("#mpRoom");
 const countEl=mpPanel.querySelector("#mpCount");
 const codeInput=mpPanel.querySelector("#mpCode");
 let socket=null, roomCode=null, remotes={};
 const myName="Игрок"+Math.floor(100+Math.random()*900);

 function setStatus(text,color="#fff"){statusEl.textContent=text;statusEl.style.color=color;}
 function updateRoomUI(){
  roomEl.textContent="Комната: "+(roomCode||"нет");
  countEl.textContent="Игроков: "+(Object.keys(remotes).length+1);
 }
 function connect(){
  if(typeof window.io!=="function"){
   setStatus("Нет Socket.IO. Запусти сервер.", "#ff9b9b");
   return;
  }
  socket=window.io();
  socket.on("connect",()=>setStatus("Подключено к серверу","#8dff9c"));
  socket.on("connect_error",()=>setStatus("Не удалось подключиться к серверу","#ff9b9b"));
  socket.on("room:created",data=>{
   roomCode=data.code;remotes={};updateRoomUI();setStatus("Комната создана!","#8dff9c");
   codeInput.value=roomCode;
  });
  socket.on("room:joined",data=>{
   roomCode=data.code;remotes=data.players||{};delete remotes[socket.id];
   updateRoomUI();setStatus("Ты в комнате!","#8dff9c");
  });
  socket.on("room:error",data=>setStatus(data.message||"Ошибка комнаты","#ff9b9b"));
  socket.on("room:state",data=>{
   remotes=data.players||{};delete remotes[socket.id];updateRoomUI();
  });
  socket.on("player:joined",data=>{
   if(data.player)remotes[data.id]=data.player;updateRoomUI();
  });
  socket.on("player:moved",data=>{
   if(data.id!==socket.id&&data.player)remotes[data.id]=data.player;
  });
  socket.on("player:left",data=>{
   delete remotes[data.id];updateRoomUI();
  });
 }
 mpPanel.querySelector("#mpCreate").addEventListener("click",()=>{
  if(!socket||!socket.connected){setStatus("Сервер не подключён","#ff9b9b");return;}
  socket.emit("room:create",{name:myName});
 });
 mpPanel.querySelector("#mpJoin").addEventListener("click",()=>{
  if(!socket||!socket.connected){setStatus("Сервер не подключён","#ff9b9b");return;}
  const code=codeInput.value.trim().toUpperCase();
  if(code.length!==5){setStatus("Код должен состоять из 5 символов","#ffcf70");return;}
  socket.emit("room:join",{code,name:myName});
 });
 function sendPlayer(){
  if(!socket||!socket.connected||!roomCode||!player)return;
  socket.emit("player:update",{
   x:player.x,y:player.y,level:player.level,facing:player.facing,
   form:currentForm&&currentForm.name?String(currentForm.name):"Птица",
   dead:!!player.dead,name:myName
  });
 }
 window.setInterval(sendPlayer,70);

 window.drawRemotePlayers=function(){
  for(const id in remotes){
   const p=remotes[id];if(!p||p.dead)continue;
   const sx=p.x-camera.x,sy=p.y-camera.y;
   if(sx<-80||sy<-80||sx>innerWidth+80||sy>innerHeight+80)continue;
   ctx.save();ctx.translate(sx,sy);ctx.scale(p.facing<0?-1:1,1);
   ctx.fillStyle="rgba(0,0,0,.22)";
   ctx.beginPath();ctx.ellipse(0,17,22,8,0,0,Math.PI*2);ctx.fill();
   ctx.fillStyle="#55bce8";
   ctx.beginPath();ctx.ellipse(0,0,19,13,0,0,Math.PI*2);ctx.fill();
   ctx.fillStyle="#267ca8";
   ctx.beginPath();ctx.moveTo(-7,1);ctx.lineTo(-27,-9);ctx.lineTo(-22,9);ctx.closePath();ctx.fill();
   ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(7,-5,4,0,Math.PI*2);ctx.fill();
   ctx.fillStyle="#172b35";ctx.beginPath();ctx.arc(8,-5,2,0,Math.PI*2);ctx.fill();
   ctx.fillStyle="#fff";ctx.font="12px Arial";ctx.textAlign="center";
   ctx.fillText((p.name||"Друг")+" · ур."+Math.max(1,p.level||1),0,-27);
   ctx.restore();
  }
 };
 connect();
})();
